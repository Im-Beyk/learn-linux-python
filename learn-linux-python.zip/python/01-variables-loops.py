# 🚀 Python Basics: Variables and Loops

name = "Ali"
age = 22

print(f"My name is {name} and I am {age} years old.")

# Loop
for i in range(5):
    print(f"Counting: {i}")