# Network Info Gathering Tool

A mini project to collect system and network information using Python.